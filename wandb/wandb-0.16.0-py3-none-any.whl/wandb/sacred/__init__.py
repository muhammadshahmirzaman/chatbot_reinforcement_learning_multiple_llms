from wandb.integration.sacred import WandbObserver

__all__ = ["WandbObserver"]
