# This module is initialized after multiprocessing spawn
