from wandb.sdk.artifacts.storage_policies.register import WANDB_STORAGE_POLICY
from wandb.sdk.artifacts.storage_policies.wandb_storage_policy import WandbStoragePolicy

__all__ = ["WANDB_STORAGE_POLICY", "WandbStoragePolicy"]
