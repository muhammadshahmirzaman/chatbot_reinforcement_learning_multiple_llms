"""Storage layout."""


class StorageLayout:
    V1 = "V1"
    V2 = "V2"
