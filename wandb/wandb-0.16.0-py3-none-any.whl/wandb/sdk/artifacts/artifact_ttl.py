"""Artifact TTL."""
from enum import Enum


class ArtifactTTL(Enum):
    INHERIT = 0
