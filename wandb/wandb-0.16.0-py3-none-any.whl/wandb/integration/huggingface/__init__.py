__all__ = ("autolog",)

from .huggingface import autolog
